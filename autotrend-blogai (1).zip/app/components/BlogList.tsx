'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';

export default function BlogList() {
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    fetch('/api/posts')
      .then((res) => res.json())
      .then((data) => setPosts(data));
  }, []);

  return (
    <div className="grid gap-6">
      {posts.map((post: any) => (
        <Link href={`/post/${post.id}`} key={post.id}>
          <div className="border p-4 rounded-xl shadow-md hover:bg-gray-50 cursor-pointer">
            {post.imageUrl && (
              <img src={post.imageUrl} alt="Capa" className="mb-4 rounded-xl w-full h-60 object-cover" />
            )}
            <h2 className="text-xl font-semibold">{post.title}</h2>
            <p className="text-sm text-gray-600">{post.subtitle}</p>
          </div>
        </Link>
      ))}
    </div>
  );
}