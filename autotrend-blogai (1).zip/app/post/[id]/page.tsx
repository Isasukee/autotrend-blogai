import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';

export default function PostPage() {
  const { id } = useParams();
  const [post, setPost] = useState<any>(null);

  useEffect(() => {
    fetch(`/api/post/${id}`)
      .then((res) => res.json())
      .then((data) => setPost(data));
  }, [id]);

  if (!post) return <p className="p-4">Carregando...</p>;

  return (
    <main className="p-4 max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold mb-4">{post.title}</h1>
      <p className="text-gray-600 mb-6">{post.subtitle}</p>
      {post.imageUrl && (
        <img src={post.imageUrl} alt="Imagem do post" className="rounded-xl mb-6 w-full h-80 object-cover" />
      )}
      <div className="prose" dangerouslySetInnerHTML={{ __html: post.content }} />
    </main>
  );
}