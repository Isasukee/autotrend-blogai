import BlogList from './components/BlogList';

export default function Home() {
  return (
    <main className="p-4 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">AutoTrend BlogAI</h1>
      <BlogList />
    </main>
  );
}