# AutoTrend BlogAI

Micro SaaS que cria e publica artigos automaticamente sobre os assuntos mais comentados da semana.